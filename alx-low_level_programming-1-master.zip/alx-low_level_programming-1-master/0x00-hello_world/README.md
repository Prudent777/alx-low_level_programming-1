First C codes with Holberton: compiling c program and hello world code
