#include <stdio.h>

int main(void)
{
int a = 5;
int b = 4;


for (a < b;;)
{
    printf("%d\n", a++);
}
}