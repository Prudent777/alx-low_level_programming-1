Variables, if else, while
