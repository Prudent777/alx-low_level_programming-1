#include "holberton.h"

/**
 * main - Entry point
 *
 * Return: Always 0.
 */
int main(void)
{
    print_alphabet();
    return (0);
}