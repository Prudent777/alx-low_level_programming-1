#include "holberton.h"

/**
 * _islower - check for lower case letter
 * @c : character to check the case
 * Return:0 or 1
 */

int _islower(int c)
{
	return (c >= 97 && c <= 122);

}
