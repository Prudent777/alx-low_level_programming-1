#include "holberton.h"

/**
 * _isdigit - check for a digit
 * @c : character to check
 * Return:0 or 1
 */

int _isdigit(int c)
{
	return (c >= 48 && c <= 57);

}
