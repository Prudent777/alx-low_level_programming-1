#include "holberton.h"
/**
 * mul - returns the product of its parameters
 * @a: int type number
 * @b: int type number
 * Return:0
 */


int mul(int a, int b)
{
return (a * b);
}
