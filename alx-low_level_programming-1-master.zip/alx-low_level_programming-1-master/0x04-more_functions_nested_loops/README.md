# More functions and tested loops

