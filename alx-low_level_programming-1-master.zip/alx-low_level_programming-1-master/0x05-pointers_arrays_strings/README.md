# Learning Pointers, arrays and strings in C
