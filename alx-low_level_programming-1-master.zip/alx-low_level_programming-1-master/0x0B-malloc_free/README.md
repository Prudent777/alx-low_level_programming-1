# Dynamic memory allocation
