#include <stdio.h>

/**
 * main - print the name of the file that was compiled
 * Return: int
 */

int main(void)
{
printf("%s\n", __FILE__);
return (0);
}
