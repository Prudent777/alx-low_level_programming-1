#ifndef ABS_DEF
#define ABS_DEF
#define ABS(x) (x > 0 ? (x) : (x) * -1)
#endif /* end ABS_DEF */
