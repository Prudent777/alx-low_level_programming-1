#ifndef SUM_DEF
#define SUM_DEF
#define SUM(x, y) (x + y)
#endif /*end SUM_DEF*/
